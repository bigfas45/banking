import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-self',
  templateUrl: './transfer-self.component.html',
  styleUrls: ['./transfer-self.component.scss']
})
export class TransferSelfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
