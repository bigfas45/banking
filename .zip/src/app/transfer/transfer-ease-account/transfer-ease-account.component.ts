import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-ease-account',
  templateUrl: './transfer-ease-account.component.html',
  styleUrls: ['./transfer-ease-account.component.scss']
})
export class TransferEaseAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
