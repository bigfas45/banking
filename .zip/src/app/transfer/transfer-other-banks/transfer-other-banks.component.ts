import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-other-banks',
  templateUrl: './transfer-other-banks.component.html',
  styleUrls: ['./transfer-other-banks.component.scss']
})
export class TransferOtherBanksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
