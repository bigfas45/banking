import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-home',
  templateUrl: './transfer-home.component.html',
  styleUrls: ['./transfer-home.component.scss']
})
export class TransferHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
