import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-beneficiaries',
  templateUrl: './transfer-beneficiaries.component.html',
  styleUrls: ['./transfer-beneficiaries.component.scss']
})
export class TransferBeneficiariesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
