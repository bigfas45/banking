import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beneficiaries-home',
  templateUrl: './beneficiaries-home.component.html',
  styleUrls: ['./beneficiaries-home.component.scss']
})
export class BeneficiariesHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
