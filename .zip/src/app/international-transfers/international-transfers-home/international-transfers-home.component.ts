import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-international-transfers-home',
  templateUrl: './international-transfers-home.component.html',
  styleUrls: ['./international-transfers-home.component.scss']
})
export class InternationalTransfersHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
